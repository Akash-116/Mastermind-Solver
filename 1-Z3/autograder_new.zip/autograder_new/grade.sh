#!/bin/bash

# instead of running 5 cases in a single .py file, I've deleted 
# the for-loop on t and duplicated the single .py into 5 .py files
python3 p1-reliable_t0.py
python3 p1-reliable_t1.py
python3 p1-reliable_t2.py
python3 p1-reliable_t3.py
python3 p1-reliable_t4.py
# instead of running 5 cases in a single .py file, I've deleted 
# the for-loop on t and duplicated the single .py into 5 .py files
python3 p1-unreliable_t0.py
python3 p1-unreliable_t1.py
python3 p1-unreliable_t2.py
python3 p1-unreliable_t3.py
python3 p1-unreliable_t4.py
#Question-2 remains unchanged
python3 p2.py